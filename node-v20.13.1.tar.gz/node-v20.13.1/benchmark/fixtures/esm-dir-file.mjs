export const dirname = import.meta.dirname;
export const filename = import.meta.filename;
