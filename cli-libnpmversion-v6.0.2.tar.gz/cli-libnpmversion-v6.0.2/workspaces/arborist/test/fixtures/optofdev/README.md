Showing a package tree involving a dev dependency which has an optional
dependency.  The children in that part of the tree have both `dev:true` and
`optional:true`.
