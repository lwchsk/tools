debugging https://github.com/npm/cli/issues/1597
