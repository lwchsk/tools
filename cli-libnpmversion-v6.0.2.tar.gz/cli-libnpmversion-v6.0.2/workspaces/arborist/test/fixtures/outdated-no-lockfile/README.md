One dep is outdated, another is missing, no lockfile

buildIdealTree shouldn't update everything, just add the missing dep
